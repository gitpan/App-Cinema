package App::Cinema::Schema;

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;


# Created by DBIx::Class::Schema::Loader v0.04006 @ 2010-01-20 13:00:02
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:gYgsSPW6WzBi4lBSP5fDew


# You can replace this text with custom content, and it will be preserved on regeneration
1;
